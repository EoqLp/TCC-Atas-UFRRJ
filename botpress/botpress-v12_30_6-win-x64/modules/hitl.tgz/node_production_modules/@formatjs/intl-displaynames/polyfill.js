require('./dist/polyfill');
